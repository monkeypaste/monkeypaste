var UiStrings = {
	EditorTemplateContactHint: `<p>利用可能な連絡先を使用すると (フェッチャー プラグインが必要)、このフィールドは、このドキュメント全体、または後で参照されるテンプレートのすべてのインスタンスに使用されます。</p>`,
	EditorTemplateDateTimeCustomHint: `<p>yy = 短い年</p>`,
	EditorTemplateDateTimeHint: `<p>現在の日付および/または時刻は、評価された瞬間から DateTime テンプレートに置き換えられます。`,
	EditorTemplateDynamicHint: `<p>このテンプレートの出現箇所はすべて、ここで指定した値に設定されます</p>`,
	EditorTemplateStaticHint: `<p>現在の日付および/または時刻は、評価された瞬間から DateTime テンプレートに置き換えられます。`,
	EditorAppendCLoseLabel: `追加を終了する`,
	EditorAppendInlineModelLabel: `段落を有効にする`,
	EditorAppendLineModeLabel: `インラインを有効にする`,
	EditorAppendManualModeLabel: `マニュアルを切り替える`,
	EditorAppendNonManualModeLabel: `マニュアルを切り替える`,
	EditorAppendPauseLabel: `クリップボードへの追加を一時停止します`,
	EditorAppendPostLabel: `前に切り替え`,
	EditorAppendPreLabel: `前に切り替え`,
	EditorAppendResumeLabel: `クリップボードへの追加を再開`,
	EditorPasteButtonAppendBeginLabel: `追加...`,
	EditorPasteButtonLabel: `ペースト`,

};